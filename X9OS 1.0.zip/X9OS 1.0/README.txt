This note is from the developer of X9OS.

If you want to edit this program please open X9OS.sb in Small Basic 1.2

If you want to run it please setup Small Basic 1.2 (Included), select X9OS.sb and run it 

This project is in beta and if you figure out how to fix any bugs please email me personally 

thecat412xfortnite@gmail.com


